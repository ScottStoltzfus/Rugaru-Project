import webapp2
import cgi
import urllib
import wsgiref.handlers
from google.appengine.ext import ndb

class rugaruUser(ndb.Model):
    fName = ndb.StringProperty(indexed=True)
    title = ndb.StringProperty(indexed=True)
    lName = ndb.StringProperty(indexed=True)
    empID = ndb.StringProperty(indexed=True)
    Pass = ndb.StringProperty(indexed=True)

class frontDoor(webapp2.RequestHandler):

    def get(self):
        self.response.out.write("""
        <!DOCTYPE html>
        <html>
        <head>
                <title>Rugaru Pictures!</title>
        </head>
        <body style="background:dodgerblue">
        <form action="/" method="post">
        <div>
                <span><strong>Employee Number</strong></span>
                &nbsp;&nbsp;&nbsp;&nbsp;
                <span><input type="text" name="empID" /></span>
        </div>
        <br>
        <div>
                <span><strong>Password</strong></span>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <span><input type="password" name="Pass" /></span>
        </div>
        <br>
                <input type="submit" value="Submit">
        </form>
        </body>
        </html>
        """)

    def post(self):
        ID = self.request.get('empID')
        P = self.request.get('Pass')
        person = rugaruUser.get_by_id(ID)
        #query = rugaruUser.query()
        #searchquery = query.filter(rugaruUser.empID==ID)
        #for i in searchquery:
        #    self.response.out.write("<p>" + i.lName + "</p>")

        if person.Pass == P:
            self.response.out.write("""
            <html>
            <head>
            <meta http-equiv="Refresh" content="0; url=/mainMenu">
            </head>
            <body>
            <body>
            </html>
            """)
        else:
            self.response.out.write("""
        <!DOCTYPE html>
        <html>
        <head>
                <title>Rugaru Pictures!</title>
        </head>
        <body style="background:dodgerblue">
        <p> Incorrect Credentials, please try again</p>
        <form action="/" method="post">
        <div>
                <span><strong>Employee Number</strong></span>
                &nbsp;&nbsp;&nbsp;&nbsp;
                <span><input type="text" name="empID" /></span>
        </div>
        <br>
        <div>
                <span><strong>Password</strong></span>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <span><input type="password" name="Pass" /></span>
        </div>
        <br>
                <input type="submit" value="Submit">
        </form>
        </body>
        </html>
        """)

class mainMenu(webapp2.RequestHandler):

    def get(self):
        self.response.out.write("""
        <!DOCTYPE html>
            <html>
                <head>
                    <title>Rugaru Pictures!</title>
                </head>
                <body style="background:dodgerblue">
                    <h1><strong>Rugaru Pictures Main Menu</strong></h1>
                    <table>
                        <form action="/picUpld">
                	<strong>Pictures</strong>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input type="submit" value="Upload">
                        </form>
                        
                        <form action="/pictureDB">
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input type="submit" value="Database">
                        </form>
                    </table>
                    <br>
                    <table>
                        <form action="/createPerm">
                        <span><strong>User Permissions</strong> </span>	
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input type="submit" value="Create">
                        </form>
                        <form action="/userPermDB">
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input type="submit" value="Database">
                        </form>
                    </table>
                    <br>
                    <table>
                        <form action="/custInFrm">
                        <span><strong>Customer Information </strong></span>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input type="submit" value="Input Form">
                        </form>
                        <form action="/custInDB">
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input type="submit" value="Database">
                        </form>
                    </table>
                    <br>
                    <form action="/printRep">
                    <span><strong>Reports </strong></span>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <input type="submit" value="Print">
                    </form>
                    <br>
                    <form action="/mainMenu">
                    <input type="submit" value="Refresh">
                    </form>
                    <br>
                    <br>
                    <br>
                    <form action="/testing">
                    <input type="submit" value="Testing">
                    </form>
                </body>
            </html>""")

class picUpld(webapp2.RequestHandler):
    
    def get(self):
        self.response.out.write("""
        <!DOCTYPE html>
            <html>
            <head>
            <style>
            .side{
                    display: inline;
            }
            </style>
                    <title>Rugaru Pictures!</title>
            </head>
            <body style="background:dodgerblue">
            <form class="side" action="/picUpld">

                    <input type="submit" value="Refresh">
            </form>
            <form class="side" action="/mainMenu">
                    <input type="submit" value="Main Menu">
            </form>
            <hr>
            <h1>Rugaru Picture Upload Page</h1>
            <!-- this is for selecting the -->
            <form action="/picUpld" method="post">
            <div>
                    <span>Tour Group </span>
                    &nbsp;&nbsp;&nbsp;&nbsp;
                    <span>
                    <select name="tourG">
                            <option value="1" >1</option>
                            <option value="2" >2</option>
                            <option value="3" >3</option>
                            <option value="4" >4</option>
                            <option value="5" >5</option>
                            <option value="6" >6</option>
                            <option value="7" >7</option>
                            <option value="8" >8</option>
                            <option value="9" >9</option>
                            <option value="10" >10</option>
                            <option value="11" >11</option>
                            <option value="12" >12</option>
                            <option value="13" >13</option>
                            <option value="14" >14</option>
                            <option value="15" >15</option>
                    </select>
                    </span>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <input type="submit" value="Add Folder">
            </div>
            <br>
            <div>
                    <span>Staff ID</span>
                    &nbsp;&nbsp;&nbsp;&nbsp;
                    <span><input type="text" name="staffID" /></span>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <span>"Date"-"Tour Group"</span>
            </div>
            <br>
            <div>
                    <span>Guide 1 ID</span>
                    <span><input type="text" name="guide1ID" /></span>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <span>"Date"-"Tour Group"</span>
            </div>
            <br>
            <div>
                    <form action="/auth.html">
                    <span>Guide 2 ID</span>
                    <span><input type="text" name="guide2ID" /></span>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <input type="submit" value="Upload"></div>
                    </form>
            <br>
            <form>
                    A date:
                    <input type="date" name="adate">
            </form>
            </form>
            <hr>
            <br>
            <br>
            </body>
            </html>
            """)
    def post(self):
        self.response.out.write("""
        <!DOCTYPE html>
        <html>
            <body> """)
        self.response.out.write("<h1>" + self.request.get('tourG') + "</h1>")
        self.response.out.write("<h2>" + self.request.get('staffID') + "</h2>")
        self.response.out.write("""
        <form action="/mainMenu">
        <input type="submit" value="Main Menu">
        </form>
        </body>
        </html>
        """)

class createPerm(webapp2.RequestHandler):
    
    def get(self):
        self.response.out.write("""
        <!DOCTYPE html>
        <html>
        <head>
        <style>
        .side{
                display: inline;
        }
        </style>
                <title>Rugaru Pictures!</title>
        </head>
        <body style="background:dodgerblue">

        <form class="side" action="/createPerm">
                <input type="submit" value="Refresh">
        </form>

        <form class="side" action="/mainMenu">
                <input type="submit" value="Main Menu">
        </form>
        <form action="/createPerm" method="post">
        <hr>
        <h1>Create Permissions for Employees</h1>
        <div>
                <span>First name</span>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <span><input type="text" name="fName" /></span>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <!-- this is for selecting the -->
                <span>Job Title </span>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <span>
                <select name="title">
                        <option value="Guide" >Guide</option>
                        <option value="Office Staff" >Office Staff</option>
                        <option value="Manager" >Manager</option>
                        <option value="Owner" >owner</option>
                </select>
        </div>
        <br>
        <div>
                <span>Last name</span>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <span><input type="text" name="lName" /></span>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <span>Employee ID</span>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <span><input type="text" name="empID" /></span>
        </div>
        <br>
        <div>
        
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="submit" value="Submit">
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <span>Password</span>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <span><input type="text" name="Pass" /></span>	
        </form>
        </div>
        </body>
        </html>

        """)
        
    def post(self):
        person = rugaruUser()
        person.fName = self.request.get('fName')
        person.title = self.request.get('title')
        person.lName = self.request.get('lName')
        person.empID = self.request.get('empID')
        person.Pass = self.request.get('Pass')
        person.key = ndb.Key('rugaruUser', self.request.get('empID'))
        person.put()

        self.response.out.write("""
        <!DOCTYPE html>
        <html>
            <body> 
                <form action="/mainMenu">
                    <input type="submit" value="Main Menu">
                </form>
            </body>
        </html>
        """)

class custInDB(webapp2.RequestHandler):
    
    def get(self):
        self.response.out.write("""
        <!DOCTYPE html>
        <html>
        <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
        .side{
                display: inline;
        }
        </style>
                <title>Rugaru Pictures</title>
        </head>
        <body style="background:dodgerblue">
        <h1><strong>Rugaru Customer Information Database</strong></h1>
        <form class="side" action="/custInDB">
                <input type="submit" value="Refresh">
        </form>
        &nbsp&nbsp&nbsp&nbsp&nbsp
        <form class="side" action="/mainMenu">
                <input type="submit" value="Main Menu">
        </form>
        <hr>
        <br>
        <div>
        <table class="updown" BORDER=3 CELLSPACING=3 CELLPADDING=3> 
        <tr>
        <th COLSPAN="3" >&nbsp&nbsp&nbsp&nbsp</th> 
        <th COLSPAN="7" >First Name</th> 
        <th COLSPAN="7" >Last Name</th> 
        <th COLSPAN="7" >E-mail</th> 
        <th COLSPAN="7" >Phone Number</th> 
        <th COLSPAN="7" >Tour Group</th> 
        <th COLSPAN="7" >Date</th> 
        <th COLSPAN="7" >Office Staff ID</th> 
        <th COLSPAN="7" >Guide1 Id</th> 
        <th COLSPAN="7" >Guide2 Id</th> 
        <th COLSPAN="7" >Status</th> 
        <th COLSPAN="7" >Commission</th> 
        </tr>
        <tr>
        <td COLSPAN="3" align=center><input type="checkbox" checked></td> 
        <td COLSPAN="7" align=center>Scott</td> 
        <td COLSPAN="7" align=center>Stoltzfus</td> 
        <td COLSPAN="7" align=center>scottstoltzfus@letu.edu</td> 
        <td COLSPAN="7" align=center>903-215-3501</td> 
        <td COLSPAN="7" align=center>1</td> 
        <td COLSPAN="7" align=center>9/15/18</td> 
        <td COLSPAN="7" align=center>2097</td> 
        <td COLSPAN="7" align=center>1083</td> 
        <td COLSPAN="7" align=center>1203</td> 
        <td COLSPAN="7" align=center>complete</td> 
        <td COLSPAN="7" align=center><input type="checkbox" checked>Yes<input type="checkbox">No</td> 
        </tr
        <tr>
        <td COLSPAN="3" ALIGN=center><input type="checkbox"></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        <td COLSPAN="7" align=center></td> 
        <td COLSPAN="7" align=center></td> 
        <td COLSPAN="7" align=center></td> 
        <td COLSPAN="7" align=center></td> 
        <td COLSPAN="7" align=center></td> 
        <td COLSPAN="7" align=center></td> 
        </tr
        <tr>
        <td COLSPAN="3" ALIGN=center><input type="checkbox"></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        <td COLSPAN="7" align=center></td> 
        <td COLSPAN="7" align=center></td> 
        <td COLSPAN="7" align=center></td> 
        <td COLSPAN="7" align=center></td> 
        <td COLSPAN="7" align=center></td> 
        <td COLSPAN="7" align=center></td> 
        </tr
        <tr>
        <td COLSPAN="3" ALIGN=center><input type="checkbox"></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        <td COLSPAN="7" align=center></td> 
        <td COLSPAN="7" align=center></td> 
        <td COLSPAN="7" align=center></td> 
        <td COLSPAN="7" align=center></td> 
        <td COLSPAN="7" align=center></td> 
        <td COLSPAN="7" align=center></td> 
        </tr
        </table>
        </div>
        <table>
        <br>
        </table>
        <table>
        <form class="updown" action="/mainMenu">
                <input type="submit" value="Authorize">
                &nbsp&nbsp&nbsp&nbsp&nbsp
                <input type="submit" value="Edit">
                &nbsp&nbsp&nbsp&nbsp&nbsp
                <input type="submit" value="Delete">
        </form>
        <form class="updown" action="/staffCustInForm">
                &nbsp&nbsp&nbsp&nbsp&nbsp
                <input type="submit" value="Input Form 2">
        </form>
        </table>
        </body>
        </html>
        """)
        
class userPermDB(webapp2.RequestHandler):
    
    def get(self):
        self.response.out.write("""
        <!DOCTYPE html>
        <html>

        <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
        .side{
            display: inline;
        }
        </style>
                <title>Rugaru Pictures</title>

        </head>

        <body style="background:dodgerblue">


        <h1><strong>Rugaru User Permissions Database</strong></h1>


        <form class="side" action="/userPermDB">
                <input type="submit" value="Refresh">
        </form>
        &nbsp&nbsp&nbsp&nbsp&nbsp
        <form class="side" action="/.">
                <input type="submit" value="Main Menu">
        </form>

        <hr>
        <br>

        <div>
        <table class="updown" BORDER=3 CELLSPACING=3 CELLPADDING=3> 
        <tr>
        <th COLSPAN="3" >&nbsp&nbsp&nbsp&nbsp</th> 
        <th COLSPAN="7" >First Name</th> 
        <th COLSPAN="7" >Last Name</th> 
        <th COLSPAN="7" >Password</th> 
        <th COLSPAN="7" >Employee ID</th> 
        <th COLSPAN="7" >Job Title</th> 
        </tr>
        <tr>
        <td COLSPAN="3" ALIGN=center><input type="checkbox" checked></td> 
        <td COLSPAN="7" ALIGN=center>Scott</td> 
        <td COLSPAN="7" ALIGN=center>Stoltzfus</td> 
        <td COLSPAN="7" ALIGN=center>youguessedit</td> 
        <td COLSPAN="7" ALIGN=center>2057</td> 
        <td COLSPAN="7" ALIGN=center>Dev</td> 
        </tr
        <tr>
        <td COLSPAN="3" ALIGN=center><input type="checkbox" checked></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        </tr
        <tr>
        <td COLSPAN="3" ALIGN=center><input type="checkbox" checked></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        </tr
        """)

class printRep(webapp2.RequestHandler):
    
    def get(self):
        self.response.out.write("""
        <!DOCTYPE html>
        <html>
        <head>
        <style>
        .side{
                display: inline;
        }
        </style>
                <title>Rugaru Pictures!</title>
        </head>
        <body style="background:dodgerblue">
        <form class="side" action="/printRep">
                <input type="submit" value="Refresh">
        </form>
        <form class="side" action="/mainMenu">
                <input type="submit" value="Main Menu">
        </form>
        <hr>
        <h1>Rugaru Reports Page</h1>
        <br>


        <TABLE class="side" BORDER=3 CELLSPACING=3 CELLPADDING=3> 
        <TR>
        <th COLSPAN="7" ALIGN=center>December 2001</th> 
        </TR>
        <TR> 
        <TD ALIGN=center>Sun</TD>
        <TD ALIGN=center>Mon</TD>
        <TD ALIGN=center>Tue</TD>
        <TD ALIGN=center>Wed</TD>
        <TD ALIGN=center>Thu</TD>
        <TD ALIGN=center>Fri</TD>
        <TD ALIGN=center>Sat</TD>
        </TR>
        <TR> 
        <TD ALIGN=center></TD>
        <TD ALIGN=center></TD>
        <TD ALIGN=center></TD>
        <TD ALIGN=center></TD>
        <TD ALIGN=center></TD>
        <TD ALIGN=center></TD>
        <TD ALIGN=center>1</TD>
        </TR>
        <TR> 
        <TD ALIGN=center>2</TD>
        <TD ALIGN=center>3</TD>
        <TD ALIGN=center>4</TD>
        <TD ALIGN=center>5</TD>
        <TD ALIGN=center>6</TD>
        <TD ALIGN=center>7</TD>
        <TD ALIGN=center>8</TD>
        </TR>
        <TR> 
        <TD ALIGN=center>9</TD>
        <TD ALIGN=center>10</TD>
        <TD ALIGN=center>11</TD>
        <TD ALIGN=center>12</TD>
        <TD ALIGN=center>13</TD>
        <TD ALIGN=center>14</TD>
        <TD ALIGN=center>15</TD>
        </TR>
        <TR> 
        <TD ALIGN=center>16</TD>
        <TD ALIGN=center>17</TD>
        <TD ALIGN=center>18</TD>
        <TD ALIGN=center>19</TD>
        <TD ALIGN=center>20</TD>
        <TD ALIGN=center>21</TD>
        <TD ALIGN=center>22</TD>
        </TR>
        <TR> 
        <TD ALIGN=center>23</TD>
        <TD ALIGN=center>24</TD>
        <TD ALIGN=center>25</TD>
        <TD ALIGN=center>26</TD>
        <TD ALIGN=center>27</TD>
        <TD ALIGN=center>28</TD>
        <TD ALIGN=center>29</TD>
        </TR>
        <TR> 
        <TD ALIGN=center>30</TD>
        <TD ALIGN=center>31</TD>
        <TD ALIGN=center></TD>
        <TD ALIGN=center></TD>
        <TD ALIGN=center></TD>
        <TD ALIGN=center></TD>
        <TD ALIGN=center></TD>
        </TR>
        <TABLE class="side" BORDER=3 CELLSPACING=3 CELLPADDING=3> 
        <TR>
        <TD COLSPAN="7" ALIGN=center><B>December 2001</B></TD> 
        </TR>
        <TR> 
        <TD ALIGN=center>Sun</TD>
        <TD ALIGN=center>Mon</TD>
        <TD ALIGN=center>Tue</TD>
        <TD ALIGN=center>Wed</TD>
        <TD ALIGN=center>Thu</TD>
        <TD ALIGN=center>Fri</TD>
        <TD ALIGN=center>Sat</TD>
        </TR>
        <TR> 
        <TD ALIGN=center></TD>
        <TD ALIGN=center></TD>
        <TD ALIGN=center></TD>
        <TD ALIGN=center></TD>
        <TD ALIGN=center></TD>
        <TD ALIGN=center></TD>
        <TD ALIGN=center>1</TD>
        </TR>
        <TR> 
        <TD ALIGN=center>2</TD>
        <TD ALIGN=center>3</TD>
        <TD ALIGN=center>4</TD>
        <TD ALIGN=center>5</TD>
        <TD ALIGN=center>6</TD>
        <TD ALIGN=center>7</TD>
        <TD ALIGN=center>8</TD>
        </TR>
        <TR> 
        <TD ALIGN=center>9</TD>
        <TD ALIGN=center>10</TD>
        <TD ALIGN=center>11</TD>
        <TD ALIGN=center>12</TD>
        <TD ALIGN=center>13</TD>
        <TD ALIGN=center>14</TD>
        <TD ALIGN=center>15</TD>
        </TR>
        <TR> 
        <TD ALIGN=center>16</TD>
        <TD ALIGN=center>17</TD>
        <TD ALIGN=center>18</TD>
        <TD ALIGN=center>19</TD>
        <TD ALIGN=center>20</TD>
        <TD ALIGN=center>21</TD>
        <TD ALIGN=center>22</TD>
        </TR>
        <TR> 
        <TD ALIGN=center>23</TD>
        <TD ALIGN=center>24</TD>
        <TD ALIGN=center>25</TD>
        <TD ALIGN=center>26</TD>
        <TD ALIGN=center>27</TD>
        <TD ALIGN=center>28</TD>
        <TD ALIGN=center>29</TD>
        </TR>
        <TR> 
        <TD ALIGN=center>30</TD>
        <TD ALIGN=center>31</TD>
        <TD ALIGN=center></TD>
        <TD ALIGN=center></TD>
        <TD ALIGN=center></TD>
        <TD ALIGN=center></TD>
        <TD ALIGN=center></TD>
        </TR>
        </TABLE>
        <table class="side">
        <tr>
        <td>
        <input type="checkbox" checked>Totals
        </td>
        </tr>
        <tr>
        <td>
        <input type="checkbox" checked>Employees
        </td>
        </tr>
        <tr>
        <td>
        <input type="checkbox" checked>Packages
        </td>
        </tr>
        </table>
        <hr>
        <form action="/printRep">
                <input type="submit" value="Print">
                <input type="submit" value="Export">
        </form>
        <br>
        <br>
        </body>
        </html>
        """)

class custInFrm(webapp2.RequestHandler):

    def get(self):
        self.response.out.write("""
            <!DOCTYPE html>

            <html>

            <head>
            <style>
            .side{
                    display: inline;
            }
            </style>
                    <title>Rugaru Pictures!</title>
            </head>

            <body style="background:dodgerblue">

            <h1>Rugaru Guest Picture Request Page</h1>

            <div>
                    <span>First name</span>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <span><input type="text" name="cFName" /></span>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

            <!-- this is for selecting the -->

                    <span>Tour Group </span>
                    <span>
                    <select name="tourG">
                            <option value="1" >1</option>
                            <option value="2" >2</option>
                            <option value="3" >3</option>
                            <option value="4" >4</option>
                            <option value="5" >5</option>
                            <option value="6" >6</option>
                            <option value="7" >7</option>
                            <option value="8" >8</option>
                            <option value="9" >9</option>
                            <option value="10" >10</option>
                            <option value="11" >11</option>
                            <option value="12" >12</option>
                            <option value="13" >13</option>
                            <option value="14" >14</option>
                            <option value="15" >15</option>

                    </select>
            </div>
            <br>
            <div>
                    <span>Last name</span>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <span><input type="text" name="cLName" /></span>
            </div>

            <br>

            <div>
                    <span>E-mail</span>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <span><input type="text" name="email" /></span>
            </div>
            <br>

            <div>
            <form action="/custInFrm">
                    <span>Phone Number</span>
                    &nbsp;&nbsp;&nbsp;
                    <span><input type="text" name="phone" /></span>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <input type="submit" value="Submit">
    
            </form>
            </div>
            </body>
            </html>
            """)

class pictureDB(webapp2.RequestHandler):

    def get(self):
        self.response.out.write("""
        <!DOCTYPE html>
        <html>
        <head>
                <title>Pictures Database</title>
        </head>
        <body style="background:dodgerblue">

        <h1><strong>Rugaru Pictures Database</strong></h1>

        <table>
        <form action="pictureDB">
                <input type="submit" value="Refresh">
        </form>
        &nbsp&nbsp&nbsp&nbsp&nbsp
        <form action="/mainMenu">
                <input type="submit" value="Main Menu">
        </form>
        </table>

        <hr>
        <br>
        <table BORDER=3 CELLSPACING=3 CELLPADDING=3> 
        <tr>
        <th COLSPAN="7" >Staff ID</th> 
        <th COLSPAN="7" >Guide1 ID</th> 
        <th COLSPAN="7" >Guide2 ID</th> 
        <th COLSPAN="7" >Tour Group</th> 
        <th COLSPAN="7" >Date&nbsp&nbsp</th> 
        <th COLSPAN="7" >Picture Download</th> 
        </tr>
        <tr>
        <td COLSPAN="7" ALIGN=center>&nbsp</td> 
        <td COLSPAN="7" ALIGN=center></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        </tr
        <tr>
        <td COLSPAN="7" ALIGN=center>&nbsp</td> 
        <td COLSPAN="7" ALIGN=center></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        </tr
        <tr>
        <td COLSPAN="7" ALIGN=center>&nbsp</td> 
        <td COLSPAN="7" ALIGN=center></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        </tr
        <tr>
        <td COLSPAN="7" ALIGN=center>&nbsp</td> 
        <td COLSPAN="7" ALIGN=center></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        </tr
        </table>

        </body>
        </html>
        """)

class staffCustInForm(webapp2.RequestHandler):

    def get(self):
        self.response.out.write("""
        <!DOCTYPE html>
        <html>

        <head>
        <style>
        .side{
                display: inline;
        }
        </style>
                <title>Rugaru Pictures!</title>
        </head>

        <body style="background:dodgerblue">

        <form class="side" action="/staffCustInForm">
                <input type="submit" value="Refresh">
        </form>
        <form class="side" action="/mainMenu">
                <input type="submit" value="Main Menu">
        </form>
        <hr>

        <h1>Rugaru Staff Picture Request Page</h1>

        <div>
                <span>First name</span>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <span><input type="text" name="info" /></span>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

        <!-- this is for selecting the -->

                <span>Group Number </span>
                <span>
                <select name="ledcolor">
                        <option value="1" >1</option>
                        <option value="2" >2</option>
                        <option value="3" >3</option>
                        <option value="4" >4</option>
                        <option value="5" >5</option>
                        <option value="6" >6</option>
                        <option value="7" >7</option>
                        <option value="8" >8</option>
                        <option value="9" >9</option>
                        <option value="10" >10</option>
                        <option value="11" >11</option>
                        <option value="12" >12</option>
                        <option value="13" >13</option>
                        <option value="14" >14</option>
                        <option value="15" >15</option>

                </select>
        </div>
        <br>
        <div>
                <span>Last name</span>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <span><input type="text" name="info" /></span>
        </div>

        <br>

        <div>
                <span>E-mail</span>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <span><input type="text" name="info" /></span>
        </div>
        <br>

        <div>
        <form action="/picUpld">
                <span>Phone Number</span>
                &nbsp;&nbsp;&nbsp;
                <span><input type="text" name="info" /></span>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="submit" value="Submit">

        </form>
        </div>

        <TABLE BORDER=3 CELLSPACING=3 CELLPADDING=3> 
        <TR>
        <TD COLSPAN="7" ALIGN=center><B>December 2001</B></TD> 
        </TR>
        <br>

        <TR> 
        <TD ALIGN=center>Sun</TD>
        <TD ALIGN=center>Mon</TD>
        <TD ALIGN=center>Tue</TD>
        <TD ALIGN=center>Wed</TD>
        <TD ALIGN=center>Thu</TD>
        <TD ALIGN=center>Fri</TD>
        <TD ALIGN=center>Sat</TD>
        </TR>

        <TR> 
        <TD ALIGN=center></TD>
        <TD ALIGN=center></TD>
        <TD ALIGN=center></TD>
        <TD ALIGN=center></TD>
        <TD ALIGN=center></TD>
        <TD ALIGN=center></TD>
        <TD ALIGN=center>1</TD>
        </TR>

        <TR> 
        <TD ALIGN=center>2</TD>
        <TD ALIGN=center>3</TD>
        <TD ALIGN=center>4</TD>
        <TD ALIGN=center>5</TD>
        <TD ALIGN=center>6</TD>
        <TD ALIGN=center>7</TD>
        <TD ALIGN=center>8</TD>
        </TR>

        <TR> 
        <TD ALIGN=center>9</TD>
        <TD ALIGN=center>10</TD>
        <TD ALIGN=center>11</TD>
        <TD ALIGN=center>12</TD>
        <TD ALIGN=center>13</TD>
        <TD ALIGN=center>14</TD>
        <TD ALIGN=center>15</TD>
        </TR>

        <TR> 
        <TD ALIGN=center>16</TD>
        <TD ALIGN=center>17</TD>
        <TD ALIGN=center>18</TD>
        <TD ALIGN=center>19</TD>
        <TD ALIGN=center>20</TD>
        <TD ALIGN=center>21</TD>
        <TD ALIGN=center>22</TD>
        </TR>

        <TR> 
        <TD ALIGN=center>23</TD>
        <TD ALIGN=center>24</TD>
        <TD ALIGN=center>25</TD>
        <TD ALIGN=center>26</TD>
        <TD ALIGN=center>27</TD>
        <TD ALIGN=center>28</TD>
        <TD ALIGN=center>29</TD>
        </TR>

        <TR> 
        <TD ALIGN=center>30</TD>
        <TD ALIGN=center>31</TD>
        <TD ALIGN=center></TD>
        <TD ALIGN=center></TD>
        <TD ALIGN=center></TD>
        <TD ALIGN=center></TD>
        <TD ALIGN=center></TD>

        </TR>
        </body>
        </html>
        """)

class testing(webapp2.RequestHandler):
    
    def get(self):
        self.response.out.write("""
        <!DOCTYPE html>
        <html>
        <head>
                <title>Rugaru Pictures!</title>
        </head>
        <body style="background:dodgerblue">
        <form action="/testing" method="post">
        <div>
                <span><strong>Employee Number</strong></span>
                &nbsp;&nbsp;&nbsp;&nbsp;
                <span><input type="text" name="empID" /></span>
        </div>
        <br>
        <div>
                <span><strong>Password</strong></span>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <span><input type="password" name="Pass" /></span>
        </div>
        <br>
                <input type="submit" value="Submit">
        </form>
        </body>
        </html>
        """)

    def post(self):
        ID = self.request.get('empID')
        P = self.request.get('Pass')
        person = rugaruUser.get_by_id(ID)
        #query = rugaruUser.query()
        #searchquery = query.filter(rugaruUser.empID==ID)
        #for i in searchquery:
        #    self.response.out.write("<p>" + i.lName + "</p>")

        if person.Pass == P:
            self.response.out.write("""
            <html>
            <head>
            <meta http-equiv="Refresh" content="0; url=/">
            </head>
            <body>
            <body>
            </html>
            """)
        else:
            self.response.out.write("""
        <!DOCTYPE html>
        <html>
        <head>
                <title>Rugaru Pictures!</title>
        </head>
        <body style="background:dodgerblue">
        <p> Incorrect Credentials, please try again</p>
        <form action="/testing" method="post">
        <div>
                <span><strong>Employee Number</strong></span>
                &nbsp;&nbsp;&nbsp;&nbsp;
                <span><input type="text" name="empID" /></span>
        </div>
        <br>
        <div>
                <span><strong>Password</strong></span>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <span><input type="password" name="Pass" /></span>
        </div>
        <br>
                <input type="submit" value="Submit">
        </form>
        </body>
        </html>
        """)
            
        

app = webapp2.WSGIApplication([("/", frontDoor),
                               ("/mainMenu", mainMenu),
                               ("/picUpld", picUpld),
                               ("/createPerm", createPerm),
                               ("/custInDB", custInDB),
                               ("/userPermDB", userPermDB),
                               ("/printRep", printRep),
                               ("/custInFrm", custInFrm),
                               ("/pictureDB", pictureDB),
                               ("/staffCustInForm", staffCustInForm),
                               ("/testing", testing)                               
                               , ], debug=True)

def main():
    app.run()

if __name__ == "__main__":
    main()
    



