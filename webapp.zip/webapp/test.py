import webapp2
import cgi
import urllib
import wsgiref.handlers
from google.cloud import datastore

class MainPage(webapp2.RequestHandler):

    def get(self):
        self.response.out.write("""
        <!DOCTYPE html>
            <html>
                <head>
                    <title>Rugaru Pictures!</title>
                </head>
                <body style="background:dodgerblue">
                    <h1><strong>Rugaru Pictures Main Menu</strong></h1>
                    <table>
                        <form action="/pupload">
                	<strong>Pictures</strong>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input type="submit" value="Upload">
                        </form>
                        
                        <form action="/authpicDB.html">
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input type="submit" value="Database">
                        </form>
                    </table>
                    <br>
                    <table>
                        <form action="/createPermissions">
                        <span><strong>User Permissions</strong> </span>	
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input type="submit" value="Create">
                        </form>
                        <form action="/authUPDB.html">
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input type="submit" value="Database">
                        </form>
                    </table>
                    <br>
                    <table>
                        <form action="/inputform.html">
                        <span><strong>Customer Information </strong></span>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input type="submit" value="Input Form">
                        </form>
                        <form action="/authCIDB.html">
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input type="submit" value="Database">
                        </form>
                    </table>
                    <br>
                    <form action="/authPrint.html">
                    <span><strong>Reports </strong></span>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <input type="submit" value="Print">
                    </form>
                    <br>
                    <form action="/">
                    <input type="submit" value="Refresh">
                    </form>
                    <br>
                    <br>
                    <br>
                    <form action="/testing.html">
                    <input type="submit" value="Testing">
                    </form>
                </body>
            </html>""")

class Pupload(webapp2.RequestHandler):
    
    def get(self):
        self.response.out.write("""
        <!DOCTYPE html>
            <html>
            <head>
            <style>
            .side{
                    display: inline;
            }
            </style>
                    <title>Rugaru Pictures!</title>
            </head>
            <body style="background:dodgerblue">
            <form class="side" action="/pupload.html">

                    <input type="submit" value="Refresh">
            </form>
            <form class="side" action="/mainmenu.html">
                    <input type="submit" value="Main Menu">
            </form>
            <hr>
            <h1>Rugaru Picture Upload Page</h1>
            <!-- this is for selecting the -->
            <form action="/pupload" method="post">
            <div>
                    <span>Tour Group </span>
                    &nbsp;&nbsp;&nbsp;&nbsp;
                    <span>
                    <select name="tourG">
                            <option value="1" >1</option>
                            <option value="2" >2</option>
                            <option value="3" >3</option>
                            <option value="4" >4</option>
                            <option value="5" >5</option>
                            <option value="6" >6</option>
                            <option value="7" >7</option>
                            <option value="8" >8</option>
                            <option value="9" >9</option>
                            <option value="10" >10</option>
                            <option value="11" >11</option>
                            <option value="12" >12</option>
                            <option value="13" >13</option>
                            <option value="14" >14</option>
                            <option value="15" >15</option>
                    </select>
                    </span>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <input type="submit" value="Add Folder">
            </div>
            <br>
            <div>
                    <span>Staff ID</span>
                    &nbsp;&nbsp;&nbsp;&nbsp;
                    <span><input type="text" name="staffID" /></span>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <span>"Date"-"Tour Group"</span>
            </div>
            <br>
            <div>
                    <span>Guide 1 ID</span>
                    <span><input type="text" name="guide1ID" /></span>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <span>"Date"-"Tour Group"</span>
            </div>
            <br>
            <div>
                    <form action="/auth.html">
                    <span>Guide 2 ID</span>
                    <span><input type="text" name="guide2ID" /></span>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <input type="submit" value="Upload"></div>
                    </form>
            <br>
            <form>
                    A date:
                    <input type="date" name="adate">
            </form>
            </form>
            <hr>
            <br>
            <br>
            </body>
            </html>
            """)
    def post(self):
        self.response.out.write("""
        <!DOCTYPE html>
        <html>
            <body> """)
        self.response.out.write("<h1>" + self.request.get('tourG') + "</h1>")
        self.response.out.write("<h2>" + self.request.get('staffID') + "</h2>")
        self.response.out.write("""
        <form action="/">
        <input type="submit" value="Main Menu">
        </form>
        </body>
        </html>
        """)

class CreatePermissions(webapp2.RequestHandler):
    
    def get(self):
        self.response.out.write("""
        <!DOCTYPE html>
        <html>
        <head>
        <style>
        .side{
                display: inline;
        }
        </style>
                <title>Rugaru Pictures!</title>
        </head>
        <body style="background:dodgerblue">

        <form class="side" action="/createPermissions">
                <input type="submit" value="Refresh">
        </form>

        <form class="side" action="/mainmenu">
                <input type="submit" value="Main Menu">
        </form>
        <form action="/createPermissions" method="post">
        <hr>
        <h1>Create Permissions for Employees</h1>
        <div>
                <span>First name</span>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <span><input type="text" name="fName" /></span>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <!-- this is for selecting the -->
                <span>Job Title </span>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <span>
                <select name="title">
                        <option value="Guide" >Guide</option>
                        <option value="Office Staff" >Office Staff</option>
                        <option value="Manager" >Manager</option>
                        <option value="Owner" >owner</option>
                </select>
        </div>
        <br>
        <div>
                <span>Last name</span>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <span><input type="text" name="lName" /></span>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <span>Employee ID</span>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <span><input type="text" name="empID" /></span>
        </div>
        <br>
        <div>
        
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="submit" value="Submit">
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <span>Password</span>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <span><input type="text" name="Pass" /></span>	
        </form>
        </div>
        </body>
        </html>

        """)
        
    def post(self):
        datastore_client = datastore.Client()
        
        complete_key = client.key('User', self.request.get('empID') )

        user = datastore.Entity(key=complete_key)
        user.update({
            'fName': self.request.get('fName'),
            'title': self.request.get('title'),
            'lName': self.request.get('lName'),
            'empid': self.request.get('empID'),
            'Pass': self.request.get('Pass')
        })

        datastore_client.put(task)
        self.response.out.write("""
        <!DOCTYPE html>
        <html>
            <body> 
                <form action="/">
                    <input type="submit" value="Main Menu">
                </form>
            </body>
        </html>
        """)



app = webapp2.WSGIApplication([('/', MainPage),
                               ("/pupload", Pupload),
                               ("/createPermissions", CreatePermissions), ], debug=True)

def main():
    app.run()

if __name__ == "__main__":
    main()
    



