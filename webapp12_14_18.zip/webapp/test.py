import webapp2
import cgi
import urllib
import wsgiref.handlers
from google.appengine.ext import ndb
import datetime
from google.appengine.ext import blobstore
from google.appengine.ext.webapp import blobstore_handlers
from google.appengine.api import images

class rugaruUser(ndb.Model):
    fName = ndb.StringProperty(indexed=True)
    title = ndb.StringProperty(indexed=True)
    lName = ndb.StringProperty(indexed=True)
    empID = ndb.StringProperty(indexed=True)
    Pass = ndb.StringProperty(indexed=True)

class pictureUpload(ndb.Model):
    tourG = ndb.StringProperty(indexed=True)
    pictureKeys = ndb.TextProperty()
    numberOfPictures = ndb.IntegerProperty(indexed=True)
    staffID = ndb.StringProperty(indexed=True)
    guide1ID = ndb.StringProperty(indexed=True)
    guide2ID = ndb.StringProperty(indexed=True)
    day = ndb.IntegerProperty(indexed=True)
    month = ndb.IntegerProperty(indexed=True)
    year = ndb.IntegerProperty(indexed=True)
    dateString = ndb.StringProperty(indexed=True)
    date = ndb.DateProperty(indexed=True)
    blob_key = ndb.BlobKeyProperty(indexed=True, repeated=True) # added repeated = true
    

class custInReq(ndb.Model):
    cFName = ndb.StringProperty(indexed=True)
    cLName = ndb.StringProperty(indexed=True)
    email = ndb.StringProperty(indexed=True)
    phone = ndb.StringProperty(indexed=True)
    tourG = ndb.StringProperty(indexed=True)
    date = ndb.DateProperty(indexed=True)
    status = ndb.StringProperty(indexed=True)


class frontDoor(webapp2.RequestHandler):

    def get(self):
        self.response.out.write("""
        <!DOCTYPE html>
        <html>
        <head>
        <meta name="viewport" content="height=device-height, initial-scale=0.4">
                <title>Rugaru Pictures!</title>
        <style>
        html, body {   
        width: 100%;   
        height: 100%;   
        font-family: "Helvetica Neue", Helvetica, sans-serif;   
        color: #444;   
        -webkit-font-smoothing: antialiased;    background: url("/images/tree_tops.jpg"); background-repeat: no-repeat;
        background-size: 100% 100%;
        }

        #container {
        position: fixed;
        width: 340px;
        height: 280px;
        top: 50%;
        left: 50%;
        margin-top: -140px;
        margin-left: -170px;
        background: #fff;
        border-radius: 7px;
        border: 1px solid #ccc;
        box-shadow: 0 1px 2px rgba(0, 0, 0, .1);
        }

        form {
            margin: 0 auto;
            margin-top: 20px;
        }

        label {
            color: #555;
            display: inline-block;
            margin-left: 18px;
            padding-top: 10px;
            font-size: 17px;
        }

        input {
            font-family: "Helvetica Neue", Helvetica, sans-serif;
            font-size: 15px;
            outline: none;
        }

        input[type=text], input[type=password] {
            color: #777;
            padding-left: 10px;
            margin: 10px;
            margin-top: 12px;
            margin-left: 18px;
            width: 290px;
            height: 35px;
            border: 1px solid #c7d0d2;
            border-radius: 7px;
            box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #f5f7f8;
        }

        input[type=text]:hover,
        input[type=password]:hover {
            border: 1px solid #b6bfc0;
            box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .7), 0 0 0 5px #f5f7f8;
        }

        input[type=text]:focus,input[type=password]:focus {
            border: 1px solid limegreen;
            box-shadow: 1px solid limegreen;
        }

        input[type=submit] {
            float: right;
            margin-right: 20px;
            margin-top: 20px;
            width: 80px;
            height: 30px;
            font-size: 14px;
            font-weight: bold;
            color: #555;
            background-color: #fff;
            border-radius: 7px;
            cursor: pointer;
            border-color: limegreen;
        }

        input[type=submit]:hover {
            background-color: limegreen
        }

        #relative{
                position: relative;
                left: 10px;
                top: 20px;
        }
        </style>
        </head>
        <body>
        <div id = "relative">
        <img src="/images/logolandscape1.png" align = "left" WIDTH=300 HEIGHT=150>
        </div>

        <div id="container">       
                <form action="/" method="post">
                        <label for="staffID">Staff ID:</label>
                        <input type="text" id="staffID" name="empID">
                        <label for="password">Password:</label>
                        <input type="password" id="password" name="Pass">
                        <input type="submit" value="Login">

        </form>
        </div>
        </body>
        </html>
        """)

    def post(self):
        ID = self.request.get('empID')
        P = self.request.get('Pass')
        person = rugaruUser.get_by_id(ID)
        if person.Pass == P:
            self.response.out.write("""
            <html>
            <head>
            <meta http-equiv="Refresh" content="0; url=/mainMenu">
            </head>
            <body>
            <body>
            </html>
            """)
        else:
            self.redirect('/')

class mainMenu(webapp2.RequestHandler):

    def get(self):
        self.response.out.write("""
            <!DOCTYPE html>
            <html>
            <head>
            <meta name="viewport" content="width=device-width, initial-scale=0.6">
                    <title>Rugaru Pictures!</title>
            <style>
            html, body {   
            width: 100%;   
            height: 100%;   
            font-family: "Helvetica Neue", Helvetica, sans-serif;   
            color: #444;   
            -webkit-font-smoothing: antialiased;    background: url("/images/tree_tops.jpg"); background-repeat: no-repeat;
            background-size: 100% 100%;
            }
            #container {
            position: fixed;
            width: 450px;
            height:300px;
            top: 40%;
            left: 44%;
            margin-top: -140px;
            margin-left: -170px;
            background: #fff;
            border-radius: 7px;
            border: 1px solid #ccc;
            box-shadow: 0 1px 2px rgba(0, 0, 0, .1);
            }
            form {
                margin: 0 auto;
                margin-top: 20px;
            }
            label {
                color: #555;
                display: inline-block;
                margin-left: 18px;
                padding-top: 10px;
                font-size: 17px;
            }
            input {
                font-family: "Helvetica Neue", Helvetica, sans-serif;
                font-size: 15px;
                outline: none;
            }
            input[type=submit] {
                margin-top: 20px;
                width: 85px;
                height: 30px;
                font-size: 14px;
                font-weight: bold;
                color: #555;
                background-color: #fff;
                border-radius: 7px;
                cursor: pointer;
                border-color: limegreen;
            }
            input[type=submit]:hover {
                background-color: limegreen;
            }
            #relative{
                    position: relative;
                    left: 10px;
                    top: 10px;
            }
            hr { 
                display: block;
                margin-top: 20px;
                margin-bottom: 5px;
                margin-left: auto;
                margin-right: auto;
                border-style: inset;
                border-width: 1px;
                border: 1px solid darkgreen;
            }
            h1{
                    position:relative;
                    text-align: center;
                    font-family: "Papyrus"; 
                    font-size: 350%;
                    font-style: italic;
                    margin-top: -10px;
                    color: black;
                    -webkit-text-stroke: 0.5px white;
            }
            </style>
            </head>
            <body>
            <div id = "relative">
            <img src="/images/logolandscape1.png" align = "left" WIDTH=300 HEIGHT=150>
            </div>
            <h1>Main Menu</h1>
            <div id = "container">
            <table>
            <form action="/authPicUpld">
                    <label for = "pictures">Pictures:</label>
                    <input type="submit" value="Upload" style = "margin-left:150px;">
            </form>
            <form action="/authPicDB">
                    <input type="submit" value="Database" style = "margin-left:18px;">
            </form>
            </table>
            <hr>
            <table>
            <form action="/authCreatePerm">
                    <label for = "userPerm">User Permissions:</label>	
                    <input type="submit" value="Create" style = "margin-left:80px;">
            </form>
            <form action="/authUserPermDB">
                    <input type="submit" value="Database" style = "margin-left:18px;">
            </form>
            </table>
            <hr>
            <table>
            <form action="/custInFrm">
                    <label for = "custIn">Customer Information:</label>
                    <input type="submit" value="Input Form" style = "margin-left:49px;">
            </form>
            <form action="/authCustInDB">
                    <input type="submit" value="Database" style = "margin-left:18px;">
            </form>
            </table>
            <hr>
            <table>
            <form action="/authPrintRep">
                    <label for = "reports">Reports:</label>
                    <input type="submit" value="Print" style = "margin-left:154px;">
            </form>
            <form action="/testing">
                    <input type="submit" value="test" style = "margin-left:18px;">
            </form>
            </table>
            </div>
            </body>
            </html>""")
        

class authPicUpld(webapp2.RequestHandler):

    def get(self):
        self.response.out.write("""
            <!DOCTYPE html>
            <html>
            <head>
                    <title>Rugaru Pictures!</title>
            <style>

            html, body {   
            width: 100%;   
            height: 100%;   
            font-family: "Helvetica Neue", Helvetica, sans-serif;   
            color: #444;   
            -webkit-font-smoothing: antialiased;    background: url("/images/trees.jpg"); background-repeat: no-repeat;
            background-size: 100% 100%;
            }

            #container {
            position: fixed;
            width: 340px;
            height: 280px;
            top: 50%;
            left: 50%;
            margin-top: -140px;
            margin-left: -170px;
            background: #fff;
            border-radius: 7px;
            border: 1px solid #ccc;
            box-shadow: 0 1px 2px rgba(0, 0, 0, .1);
            }

            form {
                margin: 0 auto;
                margin-top: 20px;
            }

            label {
                color: #555;
                display: inline-block;
                margin-left: 18px;
                padding-top: 20px;
                font-size: 17px;
            }

            input {
                font-family: "Helvetica Neue", Helvetica, sans-serif;
                font-size: 15px;
                outline: none;
            }

            input[type=text], input[type=password] {
                color: #777;
                padding-left: 10px;
                margin: 10px;
                margin-top: 12px;
                margin-left: 18px;
                width: 290px;
                height: 35px;
                border: 1px solid #c7d0d2;
                border-radius: 7px;
                box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #f5f7f8;
            }

            input[type=text]:hover,
            input[type=password]:hover {
                border: 1px solid #b6bfc0;
                box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .7), 0 0 0 5px #f5f7f8;
            }

            input[type=text]:focus,input[type=password]:focus {
                border: 1px solid limegreen;
                box-shadow: 1px solid limegreen;
            }

            input[type=submit] {
                float: right;
                margin-right: 20px;
                margin-top: 20px;
                width: 85px;
                height: 30px;
                font-size: 14px;
                font-weight: bold;
                color: #555;
                background-color: #fff;
                border-radius: 7px;
                cursor: pointer;
                border-color: limegreen;
                display: inline-block;
            }

            input[type=submit]:hover {
                background-color: limegreen
            }

            #relative{
                    position: relative;
                    left: 10px;
                    top: 20px;
            }

            </style>
            </head>
            <body>

            <div id = "relative">
            <img src="/images/logolandscape1.png" align = "left" WIDTH=300 HEIGHT=150>
            </div>

            <div id="container">
                <table>   
                    <form action="/authPicUpld" method="post">
                            <label for="staffID">Staff ID:</label>
                            <input type="text" id="staffID" name="empID">
                            <label for="password">Password:</label>
                            <input type="password" id="password" name="Pass">
                            <input type="submit" value="Login" style = "margin-left: 110px;">

                    </form>

                    <form action = "/mainMenu">
                            <input type="submit" value="Main Menu">
                    </form>
                </table>	

            </div>

            </body>
            </html>""")

    def post(self):
        ID = self.request.get('empID')
        P = self.request.get('Pass')
        person = rugaruUser.get_by_id(ID)
        if person.Pass == P:
            self.response.out.write("""
            <html>
            <head>
            <meta http-equiv="Refresh" content="0; url=/picUpld">
            </head>
            <body>
            <body>
            </html>
            """)
        else:
            self.redirect('/authPicUpld')


class picUpld(webapp2.RequestHandler):
    
    def get(self):
        upload_url = blobstore.create_upload_url('/upload_photo')
        self.response.out.write("""
        <!DOCTYPE html>
            <html>
            <head>
            <style>
            .side{
                    display: inline;
            }
            </style>
                    <title>Rugaru Pictures!</title>
            </head>
            <body style="background:dodgerblue">
            <form class="side" action="/picUpld">

                    <input type="submit" value="Refresh">
            </form>
            <form class="side" action="/mainMenu">
                    <input type="submit" value="Main Menu">
            </form>
            <hr>
            <h1>Rugaru Picture Upload Page</h1>
            <!-- this is for selecting the -->
        """)
        self.response.out.write('<form action="'+upload_url+'" method="POST" enctype="multipart/form-data">')
        self.response.out.write("""
            <div>
                    <span>Tour Group </span>
                    &nbsp;&nbsp;&nbsp;&nbsp;
                    <span>
                    <select name="tourG">
                            <option value="1" >1</option>
                            <option value="2" >2</option>
                            <option value="3" >3</option>
                            <option value="4" >4</option>
                            <option value="5" >5</option>
                            <option value="6" >6</option>
                            <option value="7" >7</option>
                            <option value="8" >8</option>
                            <option value="9" >9</option>
                            <option value="10" >10</option>
                            <option value="11" >11</option>
                            <option value="12" >12</option>
                            <option value="13" >13</option>
                            <option value="14" >14</option>
                            <option value="15" >15</option>
                            <option value="15" >16</option>
                            <option value="15" >17</option>
                            <option value="15" >18</option>
                            <option value="15" >19</option>
                            <option value="15" >20</option>
                    </select>
                    </span>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    Upload File: <input type="file" name="file" multiple required><br>
            </div>
            <br>
            <div>
                    <span>Staff ID</span>
                    &nbsp;&nbsp;&nbsp;&nbsp;
                    <span><input type="text" name="staffID" required></span>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <span>"Date"-"Tour Group"</span>
            </div>
            <br>
            <div>
                    <span>Guide 1 ID</span>
                    <span><input type="text" name="guide1ID" required></span>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <span>"Date"-"Tour Group"</span>
            </div>
            <br>
            <div>
                    <span>Guide 2 ID</span>
                    <span><input type="text" name="guide2ID" required></span>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <input type="submit" value="Upload"></div> 
            <br>
                    A date:
                    """)
        self.response.out.write('<input type="date" value="'+str(datetime.date.today())+'" name="date">')
        self.response.out.write("""
            </form>
            <hr>
            <br>
            <br>
            </body>
            </html>
        """)

        

class authCreatePerm(webapp2.RequestHandler):

    def get(self):
        self.response.out.write("""
            <!DOCTYPE html>
            <html>
            <head>
                    <title>Rugaru Pictures!</title>
            <style>

            html, body {   
            width: 100%;   
            height: 100%;   
            font-family: "Helvetica Neue", Helvetica, sans-serif;   
            color: #444;   
            -webkit-font-smoothing: antialiased;    background: url("/images/trees.jpg"); background-repeat: no-repeat;
            background-size: 100% 100%;
            }

            #container {
            position: fixed;
            width: 340px;
            height: 280px;
            top: 50%;
            left: 50%;
            margin-top: -140px;
            margin-left: -170px;
            background: #fff;
            border-radius: 7px;
            border: 1px solid #ccc;
            box-shadow: 0 1px 2px rgba(0, 0, 0, .1);
            }

            form {
                margin: 0 auto;
                margin-top: 20px;
            }

            label {
                color: #555;
                display: inline-block;
                margin-left: 18px;
                padding-top: 20px;
                font-size: 17px;
            }

            input {
                font-family: "Helvetica Neue", Helvetica, sans-serif;
                font-size: 15px;
                outline: none;
            }

            input[type=text], input[type=password] {
                color: #777;
                padding-left: 10px;
                margin: 10px;
                margin-top: 12px;
                margin-left: 18px;
                width: 290px;
                height: 35px;
                border: 1px solid #c7d0d2;
                border-radius: 7px;
                box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #f5f7f8;
            }

            input[type=text]:hover,
            input[type=password]:hover {
                border: 1px solid #b6bfc0;
                box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .7), 0 0 0 5px #f5f7f8;
            }

            input[type=text]:focus,input[type=password]:focus {
                border: 1px solid limegreen;
                box-shadow: 1px solid limegreen;
            }

            input[type=submit] {
                float: right;
                margin-right: 20px;
                margin-top: 20px;
                width: 85px;
                height: 30px;
                font-size: 14px;
                font-weight: bold;
                color: #555;
                background-color: #fff;
                border-radius: 7px;
                cursor: pointer;
                border-color: limegreen;
                display: inline-block;
            }

            input[type=submit]:hover {
                background-color: limegreen
            }

            #relative{
                    position: relative;
                    left: 10px;
                    top: 20px;
            }

            </style>
            </head>
            <body>

            <div id = "relative">
            <img src="/images/logolandscape1.png" align = "left" WIDTH=300 HEIGHT=150>
            </div>

            <div id="container">
                <table>   
                    <form action="/authCreatPerm" method="post">
                            <label for="staffID">Staff ID:</label>
                            <input type="text" id="staffID" name="empID">
                            <label for="password">Password:</label>
                            <input type="password" id="password" name="Pass">
                            <input type="submit" value="Login" style = "margin-left: 110px;">

                    </form>

                    <form action = "/mainMenu">
                            <input type="submit" value="Main Menu">
                    </form>
                </table>	

            </div>

            </body>
            </html>""")

    def post(self):
        ID = self.request.get('empID')
        P = self.request.get('Pass')
        person = rugaruUser.get_by_id(ID)

        if person.Pass == P:
            self.response.out.write("""
            <html>
            <head>
            <meta http-equiv="Refresh" content="0; url=/createPerm">
            </head>
            <body>
            <body>
            </html>
            """)
        else:
            self.response.out.write("""
        <!DOCTYPE html>
        <html>
        <head>
                <title>Rugaru Pictures!</title>
        </head>
        <body style="background:dodgerblue">
        <p> Incorrect Credentials, please try again</p>
        <form action="/authCreatePerm" method="post">
        <div>
                <span><strong>Employee Number</strong></span>
                &nbsp;&nbsp;&nbsp;&nbsp;
                <span><input type="text" name="empID" /></span>
        </div>
        <br>
        <div>
                <span><strong>Password</strong></span>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <span><input type="password" name="Pass" /></span>
        </div>
        <br>
                <input type="submit" value="Submit">
        </form>
        </body>
        </html>
        """)
        
class createPerm(webapp2.RequestHandler):
    
    def get(self):
        self.response.out.write("""
            <!DOCTYPE html>
            <html>
            <head>
            <style>
            html, body {   
            width: 100%;   
            height: 100%;   
            font-family: "Helvetica Neue", Helvetica, sans-serif;   
            color: #444;   
            -webkit-font-smoothing: antialiased;    background: url("/images/trees.jpg"); background-repeat: no-repeat;
            background-size: 100% 100%;
            }
            #container {
            position: fixed;
            width: 330px;
            height: 540px;
            top: 40%;
            left: 50%;
            margin-top: -140px;
            margin-left: -170px;
            background: #fff;
            border-radius: 7px;
            border: 1px solid #ccc;
            box-shadow: 0 1px 2px rgba(0, 0, 0, .1);
            }
            form {
                margin: 0 auto;
                margin-top: 20px;
            }
            label {
                color: #555;
                display: inline-block;
                margin-left: 18px;
                padding-top: 15px;
                font-size: 17px;
            }
            input[type=text], select {
                color: #777
                padding-left: 20px;
                width: 290px;
                height: 35px;
                margin: 10px;
                margin-top: 12px;
                margin-left: 18px;
                border: 1px solid #c7d0d2;
                border-radius: 7px;
                box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #f5f7f8;
            }
            input[type=text]:focus, select:focus {
                border: 1px solid limegreen;
                box-shadow: 1px solid limegreen;
            }
            input, select{
                font-family: "Helvetica Neue", Helvetica, sans-serif;
                font-size: 15px;
                outline: none;
            }
            input[type=submit] {
                float: right;
                margin-right: 20px;
                margin-top: -5px;
                width: 85px;
                height: 30px;
                font-size: 14px;
                font-weight: bold;
                color: #555;
                background-color: #fff;
                border-radius: 7px;
                cursor: pointer;
                border-color: limegreen;
            }
            input[type=submit]:hover {
                background-color: limegreen
            }
            #relative{
                    position: relative;
                    left: 10px;
                    top: 10px;
            }
            h1{
                    position:relative;
                    text-align: center;
                    font-family: "Papyrus"; 
                    font-size: 350%;
                    font-style: italic;
                    margin-top: 10px;
                    margin-bottom: 1px;
                    color: black;
                    -webkit-text-stroke: 0.5px white;
            }
            </style>
                    <title>Rugaru Pictures!</title>
            </head>
            <body>
            <div id = "relative">
            <img src="/images/logolandscape1.png" align = "left" WIDTH=300 HEIGHT=150>
            </div>
            <h1>Create Permissions</h1>
            <div id = "container">
                    <label for = "fName">First name:</label>
                    <input type="text" id = "fName" name="fName">
                    <label for = "lName">Last name:</label>
                    <input type="text" id = "lName" name="lName">
                    <label for = "title">Job Title:</label>
                    <select id = "title" name="title">
                            <option value="Guide" >Guide</option>
                            <option value="Office Staff" >Office Staff</option>
                            <option value="Manager" >Manager</option>
                            <option value="Owner" >owner</option>
                    </select>
                    <label for = "empID">Employee ID:</label>
                    <input type="text" id = "empID" name="empID">
                    <label for = "pass">Password:</label>
                    <input type="text" id = "Pass" name="pass">
            <form action="/picUpload">
                    <input type="submit" value="Submit" style = "margin-left: 100px;">
            </form>
            <form action = "/mainMenu">
                    <input type="submit" value="Main Menu">
            </form>
            </div>
            </body>
            </html>      
        """)
        
    def post(self):
        person = rugaruUser()
        person.fName = self.request.get('fName')
        person.title = self.request.get('title')
        person.lName = self.request.get('lName')
        person.empID = self.request.get('empID')
        person.Pass = self.request.get('Pass')
        person.key = ndb.Key('rugaruUser', self.request.get('empID'))
        person.put()

        self.response.out.write("""
        <!DOCTYPE html>
        <html>
            <body> 
                <form action="/mainMenu">
                    <input type="submit" value="Main Menu">
                </form>
            </body>
        </html>
        """)

class authCustInDB(webapp2.RequestHandler):

    def get(self):
        self.response.out.write("""
            <!DOCTYPE html>
            <html>
            <head>
                    <title>Rugaru Pictures!</title>
            <style>

            html, body {   
            width: 100%;   
            height: 100%;   
            font-family: "Helvetica Neue", Helvetica, sans-serif;   
            color: #444;   
            -webkit-font-smoothing: antialiased;    background: url("/images/trees.jpg"); background-repeat: no-repeat;
            background-size: 100% 100%;
            }

            #container {
            position: fixed;
            width: 340px;
            height: 280px;
            top: 50%;
            left: 50%;
            margin-top: -140px;
            margin-left: -170px;
            background: #fff;
            border-radius: 7px;
            border: 1px solid #ccc;
            box-shadow: 0 1px 2px rgba(0, 0, 0, .1);
            }

            form {
                margin: 0 auto;
                margin-top: 20px;
            }

            label {
                color: #555;
                display: inline-block;
                margin-left: 18px;
                padding-top: 20px;
                font-size: 17px;
            }

            input {
                font-family: "Helvetica Neue", Helvetica, sans-serif;
                font-size: 15px;
                outline: none;
            }

            input[type=text], input[type=password] {
                color: #777;
                padding-left: 10px;
                margin: 10px;
                margin-top: 12px;
                margin-left: 18px;
                width: 290px;
                height: 35px;
                border: 1px solid #c7d0d2;
                border-radius: 7px;
                box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #f5f7f8;
            }

            input[type=text]:hover,
            input[type=password]:hover {
                border: 1px solid #b6bfc0;
                box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .7), 0 0 0 5px #f5f7f8;
            }

            input[type=text]:focus,input[type=password]:focus {
                border: 1px solid limegreen;
                box-shadow: 1px solid limegreen;
            }

            input[type=submit] {
                float: right;
                margin-right: 20px;
                margin-top: 20px;
                width: 85px;
                height: 30px;
                font-size: 14px;
                font-weight: bold;
                color: #555;
                background-color: #fff;
                border-radius: 7px;
                cursor: pointer;
                border-color: limegreen;
                display: inline-block;
            }

            input[type=submit]:hover {
                background-color: limegreen
            }

            #relative{
                    position: relative;
                    left: 10px;
                    top: 20px;
            }

            </style>
            </head>
            <body>

            <div id = "relative">
            <img src="/images/logolandscape1.png" align = "left" WIDTH=300 HEIGHT=150>
            </div>

            <div id="container">
                <table>   
                    <form action="/authCustInDB" method="post">
                            <label for="staffID">Staff ID:</label>
                            <input type="text" id="staffID" name="empID">
                            <label for="password">Password:</label>
                            <input type="password" id="password" name="Pass">
                            <input type="submit" value="Login" style = "margin-left: 110px;">

                    </form>

                    <form action = "/mainMenu">
                            <input type="submit" value="Main Menu">
                    </form>
                </table>	

            </div>

            </body>
            </html>""")

    def post(self):
        ID = self.request.get('empID')
        P = self.request.get('Pass')
        person = rugaruUser.get_by_id(ID)

        if person.Pass == P:
            self.response.out.write("""
            <html>
            <head>
            <meta http-equiv="Refresh" content="0; url=/custInDB">
            </head>
            <body>
            <body>
            </html>
            """)
        else:
            self.redirect('/authCustInDB')

class custInDB(webapp2.RequestHandler):
    
    def get(self):
        self.response.out.write("""
        <!DOCTYPE html>
        <html>
        <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
        .side{
                display: inline;
        }
        </style>
                <title>Rugaru Pictures</title>
        </head>
        <body style="background:dodgerblue">
        <h1><strong>Rugaru Customer Information Database</strong></h1>
        <form class="side" action="/custInDB">
                <input type="submit" value="Refresh">
        </form>
        &nbsp&nbsp&nbsp&nbsp&nbsp
        <form class="side" action="/mainMenu">
                <input type="submit" value="Main Menu">
        </form>
        <hr>
        <br>
        <form action="/custInDB" method="post">
        <div>
        <table class="updown" BORDER=3 CELLSPACING=3 CELLPADDING=3> 
        <tr>
        <th COLSPAN="3" >&nbsp&nbsp&nbsp&nbsp</th> 
        <th COLSPAN="7" >First Name</th> 
        <th COLSPAN="7" >Last Name</th> 
        <th COLSPAN="7" >E-Mail</th> 
        <th COLSPAN="7" >Phone Number</th> 
        <th COLSPAN="7" >Tour Group</th>
        <th COLSPAN="7" >Date</th>
        <th COLSPAN="7" >Status</th> 
        </tr>""")
        query = custInReq.query(custInReq.status == 'Pending')
        for i in query:
            self.response.out.write("<tr>")
            self.response.out.write('<td COLSPAN="3" ALIGN=center><input type="checkbox"></td>')
            self.response.out.write("<td COLSPAN='7' ALIGN=center>" + i.cFName + "</td>")
            self.response.out.write("<td COLSPAN='7' ALIGN=center>" + i.cLName + "</td>")
            self.response.out.write("<td COLSPAN='7' ALIGN=center>" + i.email + "</td>")
            self.response.out.write("<td COLSPAN='7' ALIGN=center>" + i.phone + "</td>")
            self.response.out.write("<td COLSPAN='7' ALIGN=center>" + i.tourG + "</td>")
            self.response.out.write("<td COLSPAN='7' ALIGN=center>" + str(i.date) + "</td>")
            self.response.out.write("<td COLSPAN='7' ALIGN=center>" + i.status + "</td>")
            self.response.out.write("</tr>")

        self.response.out.write("""
        <tr>
        <td COLSPAN="3" ALIGN=center></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        <td COLSPAN="7" ALIGN=center></td>
        <td COLSPAN="7" ALIGN=center></td>
        <td COLSPAN="7" ALIGN=center></td> 
        </tr>
        </table>
        </div>
        <table>
        <br>
        </table>
        <table>
                <input type="submit" name="mainbutton" value="Authorize">
                &nbsp&nbsp&nbsp&nbsp&nbsp
                <input type="submit" name="mainbutton" value="Edit">
                &nbsp&nbsp&nbsp&nbsp&nbsp
                <input type="submit" name="mainbutton" value="Delete">
        </form>
        <form class="updown" action="/staffCustInForm">
                &nbsp&nbsp&nbsp&nbsp&nbsp
                <input type="submit" value="Input Form 2">
        </form>
        </table>
        </body>
        </html>
        """)
        
    def post(self):
        self.response.out.write("""
        <html><body>
        <p>test label testing 12 13 18  number 2</p>""")
        if self.request.get('mainbutton') == "Authorize":
            self.response.out.write('<p> Authorize </p>')
        if self.request.get('mainbutton') == "Edit":
            self.response.out.write('<p> Edit </p>')
        if self.request.get('mainbutton') == "Delete":
            self.response.out.write('<p> Delete </p>')
        self.response.out.write('</body></html>')
                



class authUserPermDB(webapp2.RequestHandler):

    def get(self):
        self.response.out.write("""
            <!DOCTYPE html>
            <html>
            <head>
                    <title>Rugaru Pictures!</title>
            <style>

            html, body {   
            width: 100%;   
            height: 100%;   
            font-family: "Helvetica Neue", Helvetica, sans-serif;   
            color: #444;   
            -webkit-font-smoothing: antialiased;    background: url("/images/trees.jpg"); background-repeat: no-repeat;
            background-size: 100% 100%;
            }

            #container {
            position: fixed;
            width: 340px;
            height: 280px;
            top: 50%;
            left: 50%;
            margin-top: -140px;
            margin-left: -170px;
            background: #fff;
            border-radius: 7px;
            border: 1px solid #ccc;
            box-shadow: 0 1px 2px rgba(0, 0, 0, .1);
            }

            form {
                margin: 0 auto;
                margin-top: 20px;
            }

            label {
                color: #555;
                display: inline-block;
                margin-left: 18px;
                padding-top: 20px;
                font-size: 17px;
            }

            input {
                font-family: "Helvetica Neue", Helvetica, sans-serif;
                font-size: 15px;
                outline: none;
            }

            input[type=text], input[type=password] {
                color: #777;
                padding-left: 10px;
                margin: 10px;
                margin-top: 12px;
                margin-left: 18px;
                width: 290px;
                height: 35px;
                border: 1px solid #c7d0d2;
                border-radius: 7px;
                box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #f5f7f8;
            }

            input[type=text]:hover,
            input[type=password]:hover {
                border: 1px solid #b6bfc0;
                box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .7), 0 0 0 5px #f5f7f8;
            }

            input[type=text]:focus,input[type=password]:focus {
                border: 1px solid limegreen;
                box-shadow: 1px solid limegreen;
            }

            input[type=submit] {
                float: right;
                margin-right: 20px;
                margin-top: 20px;
                width: 85px;
                height: 30px;
                font-size: 14px;
                font-weight: bold;
                color: #555;
                background-color: #fff;
                border-radius: 7px;
                cursor: pointer;
                border-color: limegreen;
                display: inline-block;
            }

            input[type=submit]:hover {
                background-color: limegreen
            }

            #relative{
                    position: relative;
                    left: 10px;
                    top: 20px;
            }

            </style>
            </head>
            <body>

            <div id = "relative">
            <img src="/images/logolandscape1.png" align = "left" WIDTH=300 HEIGHT=150>
            </div>

            <div id="container">
                <table>   
                    <form action="/authUserPermDB" method="post">
                            <label for="staffID">Staff ID:</label>
                            <input type="text" id="staffID" name="empID">
                            <label for="password">Password:</label>
                            <input type="password" id="password" name="Pass">
                            <input type="submit" value="Login" style = "margin-left: 110px;">

                    </form>

                    <form action = "/mainMenu">
                            <input type="submit" value="Main Menu">
                    </form>
                </table>	

            </div>

            </body>
            </html>""")

    def post(self):
        ID = self.request.get('empID')
        P = self.request.get('Pass')
        person = rugaruUser.get_by_id(ID)

        if person.Pass == P:
            self.response.out.write("""
            <html>
            <head>
            <meta http-equiv="Refresh" content="0; url=/userPermDB">
            </head>
            <body>
            <body>
            </html>
            """)
        else:
            self.redirect('/authUserPermDB')
        
class userPermDB(webapp2.RequestHandler):
    
    def get(self):
        self.response.out.write("""
            <!DOCTYPE html>
            <html>
            <head>
            <style>
            html, body {   
            width: 100%;   
            height: 100%;   
            font-family: "Helvetica Neue", Helvetica, sans-serif;   
            color: #444;   
            -webkit-font-smoothing: antialiased;    background: url("/images/trees.jpg"); background-repeat: no-repeat;
            background-size: 100% 100%;
            }
            table{
                    margin-top: 100px;
                    margin-left: 10px;
                    margin-right: 10px;
                    margin-bottom:-20px;
                    border: 1px solid forestgreen;
                    background-color: white;
                    border-collapse: collapse;
                    border-radius: 7px;
            }
            input {
                font-family: "Helvetica Neue", Helvetica, sans-serif;
                font-size: 15px;
                outline: none;
            }
            input[type=submit] {
                float: left;
                margin-left: 10px;
                margin-top:-20px;
                width: 90px;
                height: 30px;
                font-size: 14px;
                font-weight: bold;
                color: #555;
                background-color: #fff;
                border-radius: 7px;
                cursor: pointer;
                border-color: limegreen;
            }
            input[type=submit]:hover {
                background-color: limegreen
            }
            #customers td, #customers th {
                border: 1px solid ##4CAF50;
                padding: 8px;
            }
            #customers tr:nth-child(even){background-color: #f2f2f2;}
            #customers th {
                padding-top: 12px;
                padding-bottom: 12px;
                text-align: left;
                background-color: #4CAF50;
                color: white;
            }
            #relative{
                    position: relative;
                    left: 10px;
                    top: 10px;
            }
            h1{
                    position:relative;
                    text-align: center;
                    font-family: "Papyrus"; 
                    font-size: 350%;
                    font-style: italic;
                    margin-top: 10px;
                    margin-bottom: 1px;
                    color: black;
                    -webkit-text-stroke: 0.5px white;
            }
            </style>
                    <title>Rugaru Pictures</title>
            </head>
            <body>
            <div id = "relative">
            <img src="/images/logolandscape1.png" align = "left" WIDTH=300 HEIGHT=150>
            </div>
            <h1>User Permissions Database</h1>
            <br>
            <div>
            <table class="updown" BORDER=3 CELLSPACING=10 CELLPADDING=10 id = "customers"> 
            <tr>
            <th COLSPAN="3"  style = "border-top-left-radius: 5px">&nbsp&nbsp&nbsp&nbsp</th> 
            <th COLSPAN="7" >First Name</th> 
            <th COLSPAN="7" >Last Name</th> 
            <th COLSPAN="7" >Password</th> 
            <th COLSPAN="7" >Employee ID</th> 
            <th COLSPAN="7" style = "border-top-right-radius: 5px">Job Title</th> 
            </tr>""")
        query = rugaruUser.query()
        for i in query:
            self.response.out.write("<tr>")
            self.response.out.write('<td COLSPAN="3" ALIGN=center><input type="checkbox"></td>')
            self.response.out.write("<td COLSPAN='7' ALIGN=center>" + i.fName + "</td>")
            self.response.out.write("<td COLSPAN='7' ALIGN=center>" + i.lName + "</td>")
            self.response.out.write("<td COLSPAN='7' ALIGN=center>" + i.Pass + "</td>")
            self.response.out.write("<td COLSPAN='7' ALIGN=center>" + i.empID + "</td>")
            self.response.out.write("<td COLSPAN='7' ALIGN=center>" + i.title + "</td>")
            self.response.out.write("</tr>")

        self.response.out.write("""
            <tr>
            <td COLSPAN="3" ALIGN=center style = "border-bottom-left-radius: 5px"></td> 
            <td COLSPAN="7" ALIGN=center></td> 
            <td COLSPAN="7" ALIGN=center></td> 
            <td COLSPAN="7" ALIGN=center></td> 
            <td COLSPAN="7" ALIGN=center></td>
            <td COLSPAN="7" ALIGN=center></td> 
            <td COLSPAN="7" ALIGN=center style = "border-bottom-right-radius: 5px"></td> 
            </tr
            </table>
            <table>
            <br>
            </table>
            <table>
            <form action="/mainMenu">
                    <input type="submit" value="Edit" style = "margin-right:10px;">
                    <input type="submit" value="Delete" style = "margin-right:10px;">
            </form>
            <form action="/mainMenu">
                    <input type="submit" value="Main Menu">
            </form>
            </table>
            </div>
            </body>
            </html>""")

class authPrintRep(webapp2.RequestHandler):

    def get(self):
        self.response.out.write("""
            <!DOCTYPE html>
            <html>
            <head>
                    <title>Rugaru Pictures!</title>
            <style>

            html, body {   
            width: 100%;   
            height: 100%;   
            font-family: "Helvetica Neue", Helvetica, sans-serif;   
            color: #444;   
            -webkit-font-smoothing: antialiased;    background: url("/images/trees.jpg"); background-repeat: no-repeat;
            background-size: 100% 100%;
            }

            #container {
            position: fixed;
            width: 340px;
            height: 280px;
            top: 50%;
            left: 50%;
            margin-top: -140px;
            margin-left: -170px;
            background: #fff;
            border-radius: 7px;
            border: 1px solid #ccc;
            box-shadow: 0 1px 2px rgba(0, 0, 0, .1);
            }

            form {
                margin: 0 auto;
                margin-top: 20px;
            }

            label {
                color: #555;
                display: inline-block;
                margin-left: 18px;
                padding-top: 20px;
                font-size: 17px;
            }

            input {
                font-family: "Helvetica Neue", Helvetica, sans-serif;
                font-size: 15px;
                outline: none;
            }

            input[type=text], input[type=password] {
                color: #777;
                padding-left: 10px;
                margin: 10px;
                margin-top: 12px;
                margin-left: 18px;
                width: 290px;
                height: 35px;
                border: 1px solid #c7d0d2;
                border-radius: 7px;
                box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #f5f7f8;
            }

            input[type=text]:hover,
            input[type=password]:hover {
                border: 1px solid #b6bfc0;
                box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .7), 0 0 0 5px #f5f7f8;
            }

            input[type=text]:focus,input[type=password]:focus {
                border: 1px solid limegreen;
                box-shadow: 1px solid limegreen;
            }

            input[type=submit] {
                float: right;
                margin-right: 20px;
                margin-top: 20px;
                width: 85px;
                height: 30px;
                font-size: 14px;
                font-weight: bold;
                color: #555;
                background-color: #fff;
                border-radius: 7px;
                cursor: pointer;
                border-color: limegreen;
                display: inline-block;
            }

            input[type=submit]:hover {
                background-color: limegreen
            }

            #relative{
                    position: relative;
                    left: 10px;
                    top: 20px;
            }

            </style>
            </head>
            <body>

            <div id = "relative">
            <img src="/images/logolandscape1.png" align = "left" WIDTH=300 HEIGHT=150>
            </div>

            <div id="container">
                <table>   
                    <form action="/authPrintRep" method="post">
                            <label for="staffID">Staff ID:</label>
                            <input type="text" id="staffID" name="empID">
                            <label for="password">Password:</label>
                            <input type="password" id="password" name="Pass">
                            <input type="submit" value="Login" style = "margin-left: 110px;">

                    </form>

                    <form action = "/mainMenu">
                            <input type="submit" value="Main Menu">
                    </form>
                </table>	

            </div>

            </body>
            </html>""")

    def post(self):
        ID = self.request.get('empID')
        P = self.request.get('Pass')
        person = rugaruUser.get_by_id(ID)

        if person.Pass == P:
            self.response.out.write("""
            <html>
            <head>
            <meta http-equiv="Refresh" content="0; url=/printRep">
            </head>
            <body>
            <body>
            </html>
            """)
        else:
            self.redirect('/authPrintRep')

class printRep(webapp2.RequestHandler):
    
    def get(self):
        self.response.out.write("""
        <!DOCTYPE html>
        <html>
        <head>
        <style>
        .side{
                display: inline;
        }
        </style>
                <title>Rugaru Pictures!</title>
        </head>
        <body style="background:dodgerblue">
        <form class="side" action="/printRep">
                <input type="submit" value="Refresh">
        </form>
        <form class="side" action="/mainMenu">
                <input type="submit" value="Main Menu">
        </form>
        <hr>
        <h1>Rugaru Reports Page</h1>
        <br>
        <div>Start Date &nbsp;""")
        self.response.out.write('<input type="date" value="'+str(datetime.date.today())+'" name="startdate">')
        self.response.out.write('</div><br>')
        self.response.out.write('<div>End Date &nbsp;&nbsp;')
        self.response.out.write('<input type="date" value="'+str(datetime.date.today())+'" name="enddate"></div>')
        self.response.out.write("""
        <br>
        </TABLE>
	<table class="side">
	<tr>
	<td>
	<input type="checkbox" checked>Totals
	</td>
	</tr>
	<tr>
	<td>
	<input type="checkbox" >Employees
	</td>
	</tr>
	<tr>
	<td>
	<input type="checkbox" >Packages
	</td>
	</tr>
	</table>
        <hr>
        <form action="/printRep">
                <input type="submit" value="Print">
                <input type="submit" value="Export">
        </form>
        <br>
        <br>
        </body>
        </html>
        """)

class custInFrm(webapp2.RequestHandler):

    def get(self):
        self.response.out.write("""
            <!DOCTYPE html>
            <html>
            <head>
            <meta name="viewport" content="width=device-width, initial-scale=0.6">
            <style>
            html, body {   
            width: 100%;   
            height: 100%;   
            font-family: "Helvetica Neue", Helvetica, sans-serif;   
            color: #444;   
            -webkit-font-smoothing: antialiased;    background: url("/images/trees.jpg"); background-repeat: no-repeat;
            background-size: 100% 100%;
            }
            #container {
            position: fixed;
            width: 330px;
            height: 550px;
            top: 40%;
            left: 50%;
            margin-top: -140px;
            margin-left: -170px;
            background: #fff;
            border-radius: 7px;
            border: 1px solid #ccc;
            box-shadow: 0 1px 2px rgba(0, 0, 0, .1);
            }
            form {
                margin: 0 auto;
                margin-top: 20px;
            }
            label {
                color: #555;
                display: inline-block;
                margin-left: 18px;
                padding-top: 15px;
                font-size: 17px;
            }
            input[type=text], select {
                color: #777
                padding-left: 20px;
                width: 290px;
                height: 35px;
                margin: 10px;
                margin-top: 12px;
                margin-left: 18px;
                border: 1px solid #c7d0d2;
                border-radius: 7px;
                box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #f5f7f8;
            }
            input[type=text]:focus, select:focus {
                border: 1px solid limegreen;
                box-shadow: 1px solid limegreen;
            }
            input, select{
                font-family: "Helvetica Neue", Helvetica, sans-serif;
                font-size: 15px;
                outline: none;
            }
            input[type=submit] {
                float: right;
                margin-right: 20px;
                margin-top: 20px;
                width: 85px;
                height: 30px;
                font-size: 14px;
                font-weight: bold;
                color: #555;
                background-color: #fff;
                border-radius: 7px;
                cursor: pointer;
                border-color: limegreen;
            }
            input[type=submit]:hover {
                background-color: limegreen
            }
            #relative{
                    position: relative;
                    left: 10px;
                    top: 10px;
            }
            h1{
                    position:relative;
                    text-align: center;
                    font-family: "Papyrus"; 
                    font-size: 350%;
                    font-style: italic;
                    margin-top: 10px;
                    margin-bottom: 1px;
                    color: black;
                    -webkit-text-stroke: 0.5px white;
            }
            </style>
                    <title>Rugaru Pictures!</title>
            </head>
            <body>
            <div id = "relative">
            <img src="/images/logolandscape1.png" align = "left" WIDTH=300 HEIGHT=150>
            </div>
            <h1>Guest Picture Request</h1>
            <div id = "container">
            <table>
            <form action = "/custInFrm" method="post">
                    <label for = "tourG">Tour Group:</label>
                    <select id = "tourG" name="tourG">
                            <option value="1" >1</option>
                            <option value="2" >2</option>
                            <option value="3" >3</option>
                            <option value="4" >4</option>
                            <option value="5" >5</option>
                            <option value="6" >6</option>
                            <option value="7" >7</option>
                            <option value="8" >8</option>
                            <option value="9" >9</option>
                            <option value="10" >10</option>
                            <option value="11" >11</option>
                            <option value="12" >12</option>
                            <option value="13" >13</option>
                            <option value="14" >14</option>
                            <option value="15" >15</option>
                    </select>
                    <label for = "cFName">First name:</label>
                    <input type="text" id = "cFName" name="cFName">
                    <label for = "cLName">Last name:</label>
                    <input type="text" id="cLName" name = "cLName">
                    <label for = "email">E-mail:</label>
                    <input type="text" id = "email" name="email">
                    <label for = "phone">Phone Number:</label>
                    <input type="text" id = "phone" name="phone">
                    <input type="submit" value="Submit" style = "margin-left: 100px;">
            </form>
            <form action = "/mainMenu">
                    <input type="submit" value="Main Menu">
            </form>
            </table>
            </div>
            </body>
            </html>""")

    def post(self):
        Crequest = custInReq()
        Crequest.cFName = self.request.get('cFName')
        Crequest.cLName = self.request.get('cLName')
        Crequest.email = self.request.get('email')
        Crequest.phone = self.request.get('phone')
        Crequest.tourG = self.request.get('tourG')
        Crequest.date = datetime.date.today()
        Crequest.key = ndb.Key('custInReq', self.request.get('date'))
        Crequest.status = 'Pending'
        Crequest.put()

        self.response.out.write("""
        <!DOCTYPE html>
        <html>
        <head>
        <meta http-equiv="Refresh" content="0; url=/custInFrm">
        </head>
        <body>
        </body>
        </html>
        """)

class authPicDB(webapp2.RequestHandler):

    def get(self):
        self.response.out.write("""
            <!DOCTYPE html>
            <html>
            <head>
                    <title>Rugaru Pictures!</title>
            <style>

            html, body {   
            width: 100%;   
            height: 100%;   
            font-family: "Helvetica Neue", Helvetica, sans-serif;   
            color: #444;   
            -webkit-font-smoothing: antialiased;    background: url("/images/trees.jpg"); background-repeat: no-repeat;
            background-size: 100% 100%;
            }

            #container {
            position: fixed;
            width: 340px;
            height: 280px;
            top: 50%;
            left: 50%;
            margin-top: -140px;
            margin-left: -170px;
            background: #fff;
            border-radius: 7px;
            border: 1px solid #ccc;
            box-shadow: 0 1px 2px rgba(0, 0, 0, .1);
            }

            form {
                margin: 0 auto;
                margin-top: 20px;
            }

            label {
                color: #555;
                display: inline-block;
                margin-left: 18px;
                padding-top: 20px;
                font-size: 17px;
            }

            input {
                font-family: "Helvetica Neue", Helvetica, sans-serif;
                font-size: 15px;
                outline: none;
            }

            input[type=text], input[type=password] {
                color: #777;
                padding-left: 10px;
                margin: 10px;
                margin-top: 12px;
                margin-left: 18px;
                width: 290px;
                height: 35px;
                border: 1px solid #c7d0d2;
                border-radius: 7px;
                box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #f5f7f8;
            }

            input[type=text]:hover,
            input[type=password]:hover {
                border: 1px solid #b6bfc0;
                box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .7), 0 0 0 5px #f5f7f8;
            }

            input[type=text]:focus,input[type=password]:focus {
                border: 1px solid limegreen;
                box-shadow: 1px solid limegreen;
            }

            input[type=submit] {
                float: right;
                margin-right: 20px;
                margin-top: 20px;
                width: 85px;
                height: 30px;
                font-size: 14px;
                font-weight: bold;
                color: #555;
                background-color: #fff;
                border-radius: 7px;
                cursor: pointer;
                border-color: limegreen;
                display: inline-block;
            }

            input[type=submit]:hover {
                background-color: limegreen
            }

            #relative{
                    position: relative;
                    left: 10px;
                    top: 20px;
            }

            </style>
            </head>
            <body>

            <div id = "relative">
            <img src="/images/logolandscape1.png" align = "left" WIDTH=300 HEIGHT=150>
            </div>

            <div id="container">
                <table>   
                    <form action="/authPicDB" method="post">
                            <label for="staffID">Staff ID:</label>
                            <input type="text" id="staffID" name="empID">
                            <label for="password">Password:</label>
                            <input type="password" id="password" name="Pass">
                            <input type="submit" value="Login" style = "margin-left: 110px;">

                    </form>

                    <form action = "/mainMenu">
                            <input type="submit" value="Main Menu">
                    </form>
                </table>	

            </div>

            </body>
            </html>""")

    def post(self):
        ID = self.request.get('empID')
        P = self.request.get('Pass')
        person = rugaruUser.get_by_id(ID)
        #query = rugaruUser.query()
        #searchquery = query.filter(rugaruUser.empID==ID)
        #for i in searchquery:
        #    self.response.out.write("<p>" + i.lName + "</p>")

        if person.Pass == P:
            self.response.out.write("""
            <html>
            <head>
            <meta http-equiv="Refresh" content="0; url=/pictureDB">
            </head>
            <body>
            </body>
            </html>
            """)
        else:
            self.redirect('/authPicDB')

class pictureDB(webapp2.RequestHandler):

    def get(self):
        self.response.out.write("""
        <!DOCTYPE html>
        <html>
        <head>
                <title>Pictures Database</title>
        </head>
        <body style="background:dodgerblue">

        <h1><strong>Rugaru Pictures Database</strong></h1>

        <table>
        <form action="pictureDB">
                <input type="submit" value="Refresh">
        </form>
        &nbsp&nbsp&nbsp&nbsp&nbsp
        <form action="/mainMenu">
                <input type="submit" value="Main Menu">
        </form>
        </table>

        <hr>
        <br>
        <table class="updown" BORDER=3 CELLSPACING=3 CELLPADDING=3> 
        <tr>
        <th COLSPAN="3" >&nbsp&nbsp&nbsp&nbsp</th> 
        <th COLSPAN="7" >Tour Group</th> 
        <th COLSPAN="7" >Staff ID</th> 
        <th COLSPAN="7" >Guide 1 ID</th> 
        <th COLSPAN="7" >Guide 2 ID</th> 
        <th COLSPAN="7" >Date</th> 
        </tr>""")
        query = pictureUpload.query()
        for i in query:
            self.response.out.write("<tr>")
            self.response.out.write('<td COLSPAN="3" ALIGN=center><input type="checkbox"></td>')
            self.response.out.write("<td COLSPAN='7' ALIGN=center>" + i.tourG + "</td>")
            self.response.out.write("<td COLSPAN='7' ALIGN=center>" + i.staffID + "</td>")
            self.response.out.write("<td COLSPAN='7' ALIGN=center>" + i.guide1ID + "</td>")
            self.response.out.write("<td COLSPAN='7' ALIGN=center>" + i.guide2ID + "</td>")
            self.response.out.write("<td COLSPAN='7' ALIGN=center>" + str(i.date) + "</td>")
            self.response.out.write("</tr>")

        self.response.out.write("""
        <tr>
        <td COLSPAN="3" ALIGN=center><input type="checkbox"></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        <td COLSPAN="7" ALIGN=center></td> 
        </tr>
        </table>

        </body>
        </html>
        """)

class staffCustInForm(webapp2.RequestHandler):

    def get(self):
        self.response.out.write("""
            <!DOCTYPE html>
            <html>
            <head>
            
            <style>
            html, body {   
            width: 100%;   
            height: 100%;   
            font-family: "Helvetica Neue", Helvetica, sans-serif;   
            color: #444;   
            -webkit-font-smoothing: antialiased;    background: url("/images/trees.jpg"); background-repeat: no-repeat;
            background-size: 100% 100%;
            }
            #container {
            position: fixed;
            width: 330px;
            height: 630px;
            top: 40%;
            left: 50%;
            margin-top: -140px;
            margin-left: -170px;
            background: #fff;
            border-radius: 7px;
            border: 1px solid #ccc;
            box-shadow: 0 1px 2px rgba(0, 0, 0, .1);
            }
            form {
                margin: 0 auto;
                margin-top: 20px;
            }
            label {
                color: #555;
                display: inline-block;
                margin-left: 18px;
                padding-top: 15px;
                font-size: 17px;
            }
            input[type=text], select, input[type=date] {
                color: #777
                padding-left: 10px;
                width: 290px;
                height: 35px;
                margin: 10px;
                margin-top: 12px;
                margin-left: 18px;
                border: 1px solid #c7d0d2;
                border-radius: 7px;
                box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #f5f7f8;
            }
            input[type=text]:focus, select:focus, input[type=date]:focus {
                border: 1px solid limegreen;
                box-shadow: 1px solid limegreen;
            }
            input, select{
                font-family: "Helvetica Neue", Helvetica, sans-serif;
                font-size: 15px;
                outline: none;
            }
            input[type=submit] {
                float: right;
                margin-right: 20px;
                margin-top: 20px;
                width: 85px;
                height: 30px;
                font-size: 14px;
                font-weight: bold;
                color: #555;
                background-color: #fff;
                border-radius: 7px;
                cursor: pointer;
                border-color: limegreen;
            }
            input[type=submit]:hover {
                background-color: limegreen
            }
            #relative{
                    position: relative;
                    left: 10px;
                    top: 10px;
            }
            h1{
                    position:relative;
                    text-align: center;
                    font-family: "Papyrus"; 
                    font-size: 350%;
                    font-style: italic;
                    margin-top: 10px;
                    margin-bottom: 1px;
                    color: black;
                    -webkit-text-stroke: 0.5px white;
            }
            </style>
                    <title>Rugaru Pictures!</title>
            </head>
            <body>
            <div id = "relative">
            <img src="/images/logolandscape1.png" align = "left" WIDTH=300 HEIGHT=150>
            </div>
            <h1>Staff Picture Request</h1>
            <div id = "container">
            <table>
            <form action = "/staffCustInFrm">
                    <label for = "tourG">Tour Group:</label>
                    <select id = "tourG" name="tourG">
                            <option value="1" >1</option>
                            <option value="2" >2</option>
                            <option value="3" >3</option>
                            <option value="4" >4</option>
                            <option value="5" >5</option>
                            <option value="6" >6</option>
                            <option value="7" >7</option>
                            <option value="8" >8</option>
                            <option value="9" >9</option>
                            <option value="10" >10</option>
                            <option value="11" >11</option>
                            <option value="12" >12</option>
                            <option value="13" >13</option>
                            <option value="14" >14</option>
                            <option value="15" >15</option>
                    </select>
                    
                    <label for = "cFName">First name:</label>
                    <input type="text" id = "cFName" name="cFName">
                    
                    <label for = "cLName">Last name:</label>
                    <input type="text" id="cLName" name = "cLName">

                    <label for = "email">E-mail:</label>
                    <input type="text" id = "email" name="email">


                    <label for = "phone">Phone Number:</label>
                    <input type="text" id = "phone" name="phone">


                    <label for = "date">Date:</label>""")
        self.response.out.write('<input type="date" value="'+str(datetime.date.today())+'" name="date">')	
        self.response.out.write("""
                    <input type="submit" value="Submit" style = "margin-left: 100px;">        
            </form>
            <form action="/mainMenu">
                    <input type="submit" value="Main Menu">
            </form>
            </table>
            </div>
            </body>
            </html>
        """)

        def post(self):
            Crequest = custInReq()
            Crequest.cFName = self.request.get('cFName')
            Crequest.cLName = self.request.get('cLName')
            Crequest.email = self.request.get('email')
            Crequest.phone = self.request.get('phone')
            Crequest.tourG = self.request.get('tourG')
            Crequest.date = self.request.get('date')
            Crequest.key = ndb.Key('custInReq', self.request.get('date'))
            Crequest.put()

            self.response.out.write("""
            <!DOCTYPE html>
            <html>
                <body> 
                    <form action="/mainMenu">
                        <input type="submit" value="Main Menu">
                    </form>
                </body>
            </html>
            """)

class testing(webapp2.RequestHandler):
    
    def get(self):
              
        # To upload files to the blobstore, the request method must be "POST"
        # and enctype must be set to "multipart/form-data".
        self.response.out.write("""
        <html><body>
        <p>test label testing 12 12 18  number 2</p>""")
        self.response.out.write('<br>')
        self.response.out.write("""
        <img src="/images/logolandscape.jpg">
        <img src="/images/tree_tops.jpg">
        </body></html>""")
        self.redirect('DownloadPhotoHandler')
        


class PhotoUploadHandler(blobstore_handlers.BlobstoreUploadHandler):
    
    def post(self):
        testupload = self.get_uploads()  
        upload =  testupload[0]  #self.get_uploads()[1]         self.get_uploads()[0] 
        x = 0
        keys =[]
        for i in testupload:
            keys.append(testupload[x].key()) #keys = keys + str(testupload[x].key()) + ','
            x = x+1
        date_string = self.request.get('date')

        thedate = datetime.datetime.strptime(date_string, '%Y-%m-%d')
        
        upld = pictureUpload()
        upld.tourG = self.request.get('tourG')
        upld.numberOfPictures = x
        #upld.pictureKeys = keys
        upld.staffID = self.request.get('staffID')
        upld.guide1ID = self.request.get('guide1ID')
        upld.guide2ID = self.request.get('guide2ID')
        upld.date = thedate.date()
        upld.day = thedate.day
        upld.month = thedate.month
        upld.year = thedate.year
        upld.dateString = date_string
        upld.blob_key = keys # was upload.key()
        upld.put()
        self.redirect('/view_photo/%s' % upload.key())
        

class ViewPhotoHandler(blobstore_handlers.BlobstoreDownloadHandler):
    
    def get(self, photo_key):
        query = pictureUpload.query(pictureUpload.numberOfPictures == 7)
        keys = []
        self.response.out.write("""
        <html><body>
        <p>test label testing 12 13 18  number 2</p>""")
        for i in query:
            keys = i.blob_key
            thedate = i.date
            self.response.out.write('<p>' + i.date.__str__() + '</p>')

        display_pictures = []
        for b in keys:
            #theblob = 
            #self.response.out.write('<a href="'++'" download target="_blank">')
            #self.response.out.write('</a>')
            display_pictures.append(images.get_serving_url(b))

        
        for c in display_pictures:
            self.response.out.write('<img src="'+c+'">')
            self.response.out.write('<br>')

        self.response.out.write('</body></html>')

        #for d in keys:
        #    images.delete_serving_url(d)
        #    images.delete_serving_url(d)

#working file download code
class DownloadPhotoHandler(blobstore_handlers.BlobstoreDownloadHandler):
    
    def get(self):
        #query the the pictureupload storage for a pictureupload record
        query = pictureUpload.query(pictureUpload.numberOfPictures == 7)
        #create an empty list
        keys = []

        #get the list of blob keys out of the query result
        for i in query:
            keys = i.blob_key
        
        #send the picture from the second blob key as a file that automatically downloads
        if not blobstore.get(keys[1]): 
            self.error(404)
        else:
            self.send_blob(blobstore.BlobInfo(keys[1]), save_as=True)
            

        
        

app = webapp2.WSGIApplication([("/", frontDoor),
                               ("/mainMenu", mainMenu),
                               ("/authPicUpld", authPicUpld),
                               ("/picUpld", picUpld),
                               ("/authCreatePerm", authCreatePerm),
                               ("/createPerm", createPerm),
                               ("/authCustInDB", authCustInDB),
                               ("/custInDB", custInDB),
                               ("/authUserPermDB", authUserPermDB),
                               ("/userPermDB", userPermDB),
                               ("/authPrintRep", authPrintRep),
                               ("/printRep", printRep),
                               ("/custInFrm", custInFrm),
                               ("/authPicDB", authPicDB),
                               ("/pictureDB", pictureDB),
                               ("/staffCustInForm", staffCustInForm),
                               ('/upload_photo', PhotoUploadHandler),
                               ('/view_photo/([^/]+)?', ViewPhotoHandler),
                               ('/DownloadPhotoHandler', DownloadPhotoHandler),
                               ("/testing", testing)
                               , ], debug=True)

def main():
    app.run()

if __name__ == "__main__":
    main()
    



